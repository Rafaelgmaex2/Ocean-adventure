Ocean Adventure — Protótipo
------------------------------------
Conteúdo:
- index.html : protótipo do jogo em HTML5 com suporte a teclado, gamepad (Xbox/PS) e controles virtuais para celular.

Como usar:
1. Extraia o ZIP em uma pasta.
2. Abra `index.html` em um navegador moderno (Chrome, Edge, Firefox).
3. Teste teclado: A/D ou ←/→ para mover, Espaço para pular.
4. Conecte um controle via USB/Bluetooth e pressione um botão para permitir Gamepad API.
5. Em celular, use o joystick e botão na tela.

Observação:
- Este protótipo é totalmente original e NÃO contém conteúdo de jogos comerciais.
- Sinta-se à vontade para pedir melhorias: sprites, inimigos, áudio, níveis ou empacotamento para hospedagem.
